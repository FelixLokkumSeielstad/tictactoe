<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Style.css">
    <title>Document</title>
</head>

<body>
    <nav class="nav">
        <ul class="nav-links">
            <li><a href="index.php" id="activenav">Home</a></li>
            <li><a href="About.php">About</a></li>
            <li><a href="Download.php">Download</a></li>
            <li><a href="faq.php">FAQ</a></li>
            <li><a href="Login.php">Log in</a></li>
        </ul>
        <div class="burger">
            <div class="line1"></div>
            <div class="line2"></div>
            <div class="line3"></div>
        </div>
    </nav>

    <section class="faq">
        <h1>Faq</h1>
        <h3>hvorfor er den son</h3>
        <p>fordi</p>
        <h1>Faq</h1>
        <h3>hvorfor er den son</h3>
        <p>fordi</p>
        <h1>Faq</h1>
        <h3>hvorfor er den son</h3>
        <p>fordi</p>
    </section>

</body>

</html>