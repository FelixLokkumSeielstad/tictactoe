<?php

$host = "localhost";
$user = "FelixAdmin";
$password = "FelixAdmin";
$database = "mywbsdb";

$connect = mysqli_connect($host, $user, $password, $database);
?> 